# Skill: Dashboard AIOps con Azure Managed Grafana

Con esta skill, Claude Code crea en **tu** suscripción de Azure un Grafana con un
dashboard de operaciones: qué tienes levantado, qué cobra por hora, estado de cada
servicio, métricas de tus endpoints de Azure ML y Web Apps, anomalías y alertas.

## 1. Requisitos

- [Claude Code](https://claude.com/claude-code)
- Azure CLI con sesión iniciada: `az login`
- Python 3.10 o superior
- Rol **Owner** (o *User Access Administrator*) en tu suscripción. Claude lo
  revisa antes de crear nada y te dice qué hacer si no lo tienes.

## 2. Instalar

Copia las dos carpetas en tu carpeta de skills de Claude Code:

```bash
# macOS / Linux
mkdir -p ~/.claude/skills && cp -R azure-grafana-aiops azure-grafana-aiops-cleanup ~/.claude/skills/
```

```powershell
# Windows (PowerShell)
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Copy-Item -Recurse azure-grafana-aiops, azure-grafana-aiops-cleanup "$HOME\.claude\skills\"
```

Abre Claude Code de nuevo para que las detecte.

## 3. Usar

En Claude Code escribe:

```
/azure-grafana-aiops
```

Claude revisa requisitos y permisos, te muestra el costo y te pide confirmación
antes de crear algo. Al final te da la URL de tu dashboard.

Si levantas servicios nuevos, vuelve a correr `/azure-grafana-aiops`: no crea
otro Grafana, solo actualiza el dashboard.

## 4. Al terminar (importante: cobra por hora)

```
/azure-grafana-aiops-cleanup
```

Grafana Standard cuesta ~$0.068/h (~$1.6 al día) mientras exista.
